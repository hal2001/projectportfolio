// Example of Creating Class: Puppy


public class Puppy {

    public Puppy(String name){
        System.out.println("Passed Name Is: " + name);

    }
    
    public static void main(String args[]){

    Puppy myPuppy = new Puppy("tommy");

    }
}

