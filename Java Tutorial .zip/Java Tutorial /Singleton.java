//Singleon Class Exmple

public class Singleton {

    private static Singleton singleton = new Singleton();
    
    public static Singleton getInstance() {
        return singleton;
    }
    
    private Singleton(){ }
    
    protected static void demoMethod( ){
        System.out.println("demoMethod for Singleton");
    }
}