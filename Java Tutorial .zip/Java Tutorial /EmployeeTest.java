//Testing Class Employee Created in Separate Java File
//Import Necessary Packages
import java.io.*;

public class EmployeeTest{
    public static void main(String args[]){
        //Creating New Objects
        Employee empOne = new Employee("Stephen Darcy");
        Employee empTwo = new Employee("Christian Sherland");

        //Invoking Constructors for Objects
        empOne.empAge(26);
        empOne.empDesignation("Mechanical Engineer");
        empOne.empSalary(70000);
        empOne.printEmployee();
        
        empTwo.empAge(25);
        empTwo.empDesignation("Software Engineer");
        empTwo.empSalary(110000);
        empTwo.printEmployee();
        
 }}
