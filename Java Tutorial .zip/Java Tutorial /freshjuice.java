//Fresh Juice Test


public class freshjuice{
    enum freshjuicesize{Small, Medium, Large}
    freshjuicesize size;
}

public class freshjuicetest{
    public static void freshjuicetest(String args[]){
        freshjuice juice = new freshjuice();
        juice.size = freshjuicesize.Medium;
        System.out.println("Size: " + juice.size);
    }
}

