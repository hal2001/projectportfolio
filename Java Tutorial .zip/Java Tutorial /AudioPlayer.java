//Access Modifier Example
//Open Speaker is now only visible to the subclass only
// If defined as public, it would be visible everywhere else
// If defined as private, it would only be visible within any class other than AudioPlayer


public class AudioPlayer{

    protected boolean openSpeaker(Speaker sp){
        
    }

}

class StreamingAudioPlayer {

    boolean openSpeaker(Speaker sp) {
        
        
    }
}

