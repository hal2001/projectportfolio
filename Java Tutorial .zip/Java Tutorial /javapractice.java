//Java Tutorial: Taweh Beysolow

public class javapractice {
    public static void main(String args[]){
        System.out.println("Hello World!");
    }
}

//Enum Example
public class freshjuice{
    enum freshjuicesize{Small, Medium, Large}
    freshjuicesize size;
}

public class freshjuicetest{
    public static void freshjuicetest(String args[]){
        freshjuice juice = new freshjuice();
        juice.size = freshjuicesize.Medium;
        System.out.println("Size: " + juice.size);
    }
}


//Sample Class
public class Dog{

    String breed;
    int AgeC
    String color;
    
    //The Following Lines Described Methods Within This Class
    //From These Methods, Values Can Be Accessed
    void barking(){
    }
    void hungry(){
    }
    void sleeping(){
    }
}



